MATRIX QUEST — GITHUB BRANCH UPDATE

This is a standalone single-file version of Matrix Quest. The website code is in index.html.

IMPORTANT:
- Make a new branch first so your main branch stays unchanged.
- This version is designed as one complete index.html file. If your existing project has a different multi-file structure, do not replace files blindly; merge the features into the matching files instead.
- The profile name and progress are saved only in the player's browser (localStorage). This is not secure account login and does not sync across devices.

GITHUB STEPS (website interface):
1. Open your repository on GitHub.
2. Click the branch selector (usually says main).
3. Type a new branch name, for example: matrix-quest-homepage-update, and choose Create branch.
4. Open index.html in that branch. If it does not exist, use Add file > Create new file and name it index.html.
5. Choose Edit (pencil icon) for index.html. Replace its contents with the full contents of the provided index.html file. If creating it, paste all contents into the editor.
6. Click Commit changes and make sure the commit is to your new branch, not main.
7. Test the branch by opening the HTML file locally in a browser or enabling GitHub Pages for the branch if your repository setup supports that.
8. When it looks right, open Pull requests > New pull request. Set base: main and compare: matrix-quest-homepage-update.
9. Review the changes and create the pull request, then merge it when ready.

If the existing main branch already has a different index.html or multiple HTML/CSS/JS files, replacing index.html will replace that page with this standalone version. Back up your current version first.
